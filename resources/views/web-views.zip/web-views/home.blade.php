@extends('layouts.front-end.app')
<style>
    .row {
        margin-right: 0px !important;
    }

    /* .old-price {
        display: block;
        text-decoration: line-through;
        margin-right: 5px;

    } */
    /* @media screen and (max-width: 320px){
        .price{
            font-size: 21px;
        }
    } */
</style>
@section('content')
<!--<div class="row mt-1 ml-5">-->
<!--    <div class="col-12 col-lg-4">-->

<!--        <form action="{{route('search')}}" method="get">-->
<!--            <div class="row" >-->
<!--                <div class="col-10 ">-->
<!--                    <input type="search" style="border:none;" class="shadow bg-body rounded" placeholder="Search Coupon" required=""-->
<!--                        name="key">-->
<!--                </div>-->
<!--                <div class="col-2" style="margin-left:-65px;">-->
<!--                    <button style="border:none;"  type="submit"><i class="fa fa-search"></i></button>-->
<!--                </div>-->
<!--            </div>-->

<!--        </form>-->
<!--    </div>-->
<!--</div>-->
<div class="owl-carousel owl-theme mb-1">
    <div class="item">
        <a href="#">
            <img src="{{ asset('public/assets/frontend') }}/images/slider1.png" alt="">
        </a>
    </div>
    <div class="item">
        <a href="#">
            <img src="{{ asset('public/assets/frontend') }}/images/slider2.png" alt="">
        </a>
    </div>
</div>
{{-- <div class="bgWhite features pt-25 pb-100 clearfix">
    <div class="container">
        <div class="feature">
            <a href="#">
                <div class="img-container">
                    <img src="{{ asset('public/assets/frontend') }}/images/gallery_5d79efc0b59a0.jpg" alt="">
                    <div class="exp-date" data-countdown="Fri Dec 27 2019 21:39:00 +0100"></div>
                </div>
                Womens clothing discounts
            </a>
        </div>
        <div class="feature">
            <a href="#">
                <div class="img-container">
                    <img src="{{ asset('public/assets/frontend') }}/images/gallery_5d79f06fc3c10.jpg" alt="">
                    <div class="exp-date" data-countdown="Thu Oct 10 2019 22:54:00 +0200"></div>
                </div>
                Sports articles on sale
            </a>
        </div>
    </div>
</div> --}}
<div class="bgGray  clearfix mt-5">
    <div class="container">
        <h2 class="mt-1">Best Deals & Coupons </h2>

        @if ($bestCoupon->count() > 0)
        <div class="items mt-25 mb-25 clearfix">
            @foreach ($bestCoupon as $data)
            <div class="item" id="coupon-20">
                {{-- {{$data->coupon->sum('price')}} --}}
                <div class="top">
                    <div class="h-info"></div>
                    <img src="{{ asset('storage/app/public/coupon') }}/{{ $data->image }}" alt="">
                </div>
                <div class="info">
                    {{-- <div class="row">
                        <div class="col-6 price">
                            <h3 class="old-price  text-danger">₹ {{ number_format($data->discount, 2) }}</h3>
                        </div>
                        <div class="col-6 price">
                            <h3 class="h3  ">₹ {{ number_format($data->price, 2) }}</h3>
                        </div>
                    </div> --}}
                    <p class="h3"> <span class="" style="text-decoration: line-through; color: red">₹ {{
                            number_format($data->discount, 2) }}</span>
                        ₹
                        {{ number_format($data->price, 2) }}

                    </p>
                    <a href="{{ route('coupon-details', [$data->slug]) }}">
                        <!--<h3 class="old-price h3 text-danger">₹ {{ number_format($data->discount, 2) }}</h3>-->
                        <h3 title="" class="text-dark">
                            <!--<span>₹ {{ number_format($data->price, 2) }}</span> <br>-->
                            {{ $data->title }}
                        </h3>
                    </a>
                    {{-- <div class="stats"><span class="badge badge-info h2" style="font-size: 15px;">{{
                            $data->category->title }}</span></div> --}}
                    {{-- <div class="stats mt-2"><b></b> <span class="badge badge-primary h2"
                            style="font-size: 15px;">Validity {{$data->expiry_date}} months from date of
                            subscribe</span></div> --}}
                    <div class="stats h4"><b>No of coupon</b> <span class="badge badge-success h3"
                            style="font-size: 10px;">{{
                            $data->coupon->count() }}</span></div>
                    {{-- By <strong>
                        <a href="{{ route('coupon-details', [$data->slug]) }}">
                            <span class="badge badge-success h3" style="font-size: 18px;">{{ $data->vendor->company_name
                                }}</span>
                        </a></strong> --}}
                    <a href="{{ route('coupon-details', [$data->slug]) }}" class="link">Coupon View</a>

                    {{-- <div class="expiration"><span class="expired exp-date">Expired</span></div> --}}
                </div>

            </div>
            @endforeach
            {{-- <div class="item" id="coupon-20">

                <div class="top">
                    <div class="h-info"></div>
                    <img src="{{ asset('public/assets/frontend') }}/images/logo_5c587de925db5.png" alt="">
                </div>

                <div class="info">
                    <a href="coupon/12_off_on_50-20.html">
                        <h5 title="12% Off on $50+">12% Off on $50+</h5>
                    </a>
                    By <strong><a href="{{ route('coupon-details') }}">Poplink's</a></strong><a
                        href="{{ route('coupon-details') }}" target="_blank" class="link">Purchages</a>
                    <div class="stats">53 used, 100% success rate</div>
                    <div class="expiration"><span class="expired exp-date">Expired</span></div>






                </div>



            </div> --}}
        </div>
        @else
        <div class="items mt-25 mb-25 clearfix">
            <h1 class="text-danger">Coupon not found</h1>
        </div>

        @endif

    </div>
</div>

<div class="bgWhite pt-100 pb-100 clearfix">
    <div class="container">
        <h2><strong>Top</strong> Stores </h2>
        <ul class="boxed-items boxed-stores clearfix mt-25 mb-25">
            @foreach ($vendor as $v)
            <li>
                <a href="{{route('store.product',[$v->id])}}">
                    <img {{-- src="{{ asset('public/assets/frontend') }}/images/logo_5c587c783fedb.png" --}}
                        src="{{ asset('storage/app/public/vender/company_logo/') }}/{{ $v->logo }}" alt="">

                </a>

                <p>{{$v->company_name}}</p>

            </li>
            @endforeach
        </ul>
    </div>
</div>
<div class="bgGray pt-100 pb-100 clearfix">
    <div class="container">
        <h2><strong>Top</strong> Categories </h2>
        <div class="items mt-25 mb-25 clearfix">
            <ul class="boxed-items boxed-categories clearfix mt-25 mb-25">
                @foreach ($topCategory as $topCat)
                <li style="background:rgb(108, 79, 61)"><a href="{{route('category.product',[$topCat->id])}}">{{
                        $topCat->title }}</a></li>
                @endforeach


            </ul>
        </div>
    </div>
</div>
<div class="bgBlack pt-100 pb-100 clearfix">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8 text-center">
                <h2 class="mb-50">Subscribe to be notified when<br> <strong>great coupons & big discounts</strong>
                    are added </h2>
                <div class="subscribe_form other_form">
                    <form method="POST" action="{{route('subscribe')}}">
                        @csrf
                        <input type="email" class="shadow  bg-body rounded text-white" name="email" value=""
                            placeholder="Email Address" required="">
                        <button type="submit" class="text-white">Subscribe</button>
                    </form>

                </div>
            </div>
        </div>
    </div>
</div>
<div class="bgBlack pt-75 pb-75 clearfix">
    <div class="container">
        <div class="row justify-content-center">
            {{-- <div class="col-md-6 align-self-center">
                <h2 class="mb-0 m-mb-15 text-center text-md-left">Get the <strong>latest</strong> coupons &
                    discounts </h2>
            </div>
            <div class="col-md-6 text-center text-md-right">
                <ul class="button-set lh-50">
                    <li><a href="coupons-7.html">Coupons</a></li>
                    <li><a href="coupons-7.html">Popular</a></li>
                    <li><a href="coupons-7.html">Coupon Codes</a></li>
                    <li><a href="products-3.html">Products</a></li>
                </ul>
            </div> --}}
        </div>
    </div>
</div>
@endsection
