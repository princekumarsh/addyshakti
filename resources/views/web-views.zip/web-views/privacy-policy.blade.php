@extends('layouts.front-end.app')

@section('content')
<style>
    .video {
        height: 50%;
        width: 100%;
    }
</style>
<div class="pt50 pb50">

    

</div>
@endsection


<script src="">
    // function buyNow() {
    //    alert('jjj');
    //     $(.typeAdd).append('<input type="hidden" name="field_name" value="buy_now" /> ');
    //     return true;

    // }

    //  function AddToCart() {

    //     $(.typeAdd).append('<input type="hidden" name="field_name" value="AddToCart" /> ');
    //     return true;

    // }



</script>
