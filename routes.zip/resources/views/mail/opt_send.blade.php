<!-- # Moyenne island -->
<strong></strong> </strong><br>

<p>Please use the following OTP to continue with your forgot password process on Addy.</p>
<p>Validation code is:
<h4><b>{{ $code }}</b></h4>
</p>
<p>The above OTP is valid for 5 minutes.</p>




Regards,<br>
<p>Addy</p>